import { useState } from 'react';
import { Youtube, Video, Scissors, Building2, Brain, Zap, Menu, X, ArrowRight, Sparkles, Globe, ShieldCheck, Play, Film } from 'lucide-react';
import { YouTubeFactory } from '@/components/engines/YouTubeFactory';
import { UGCAdsGenerator } from '@/components/engines/UGCAdsGenerator';
import { VideoEditingAudit } from '@/components/engines/VideoEditingAudit';
import { BusinessAdsSystem } from '@/components/engines/BusinessAdsSystem';
import { PricingBrain } from '@/components/engines/PricingBrain';
import { AIVideoStudio } from '@/components/engines/AIVideoStudio';
import { LANGUAGES } from '@/lib/languages';

type View = 'home' | 'youtube' | 'ugc' | 'edit' | 'business' | 'pricing' | 'studio';

interface EngineCard {
  id: View;
  number: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  gradient: string;
  tag?: string;
}

const engines: EngineCard[] = [
  {
    id: 'youtube',
    number: '01',
    title: 'YouTube Automation Factory',
    description: 'Topic in. Ready-to-upload video out — viral script, voiceover, B-roll, auto-edit, SEO.',
    icon: <Youtube className="h-6 w-6" />,
    gradient: 'from-red-500 to-rose-600',
    tag: 'Membership',
  },
  {
    id: 'ugc',
    number: '02',
    title: 'UGC Ads Generator',
    description: 'Ultra-realistic testimonial ads. $500 for 4K. Pay-per-second. No packages.',
    icon: <Video className="h-6 w-6" />,
    gradient: 'from-amber-400 to-orange-500',
    tag: 'Main Product',
  },
  {
    id: 'edit',
    number: '03',
    title: 'Video Editing & Audit',
    description: 'Auto-cut silence, zoom, captions. Virality score with hook suggestions & thumbnails.',
    icon: <Scissors className="h-6 w-6" />,
    gradient: 'from-cyan-500 to-blue-600',
  },
  {
    id: 'business',
    number: '04',
    title: 'Business Ads System',
    description: '4-step onboarding: category, script type, duration, quality. Multipliers built in.',
    icon: <Building2 className="h-6 w-6" />,
    gradient: 'from-emerald-500 to-teal-600',
  },
  {
    id: 'pricing',
    number: '05',
    title: 'Dynamic Pricing Brain',
    description: 'Live pricing calculator with geo-detection. 1 Credit = $1 USD. Formula-driven.',
    icon: <Brain className="h-6 w-6" />,
    gradient: 'from-violet-500 to-fuchsia-600',
  },
  {
    id: 'studio',
    number: '06',
    title: 'AI Video Studio',
    description: 'Wan3.0-powered generation: text-to-video, image-to-video, and reference-to-video modes.',
    icon: <Film className="h-6 w-6" />,
    gradient: 'from-violet-500 to-fuchsia-600',
    tag: 'New',
  },
];

export default function App() {
  const [view, setView] = useState<View>('home');
  const [mobileNav, setMobileNav] = useState(false);

  const navigate = (v: View) => {
    setView(v);
    setMobileNav(false);
  };

  const renderEngine = () => {
    switch (view) {
      case 'youtube': return <YouTubeFactory />;
      case 'ugc': return <UGCAdsGenerator />;
      case 'edit': return <VideoEditingAudit />;
      case 'business': return <BusinessAdsSystem />;
      case 'pricing': return <PricingBrain />;
      case 'studio': return <AIVideoStudio />;
      default: return null;
    }
  };

  const navItems = engines.filter((e) => e.id !== 'home');

  return (
    <div className="min-h-screen bg-[#0a0e1a] text-slate-200">
      {/* Top Bar */}
      <header className="sticky top-0 z-50 border-b border-slate-800/60 bg-[#0a0e1a]/80 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6">
          <button onClick={() => navigate('home')} className="flex items-center gap-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600">
              <Zap className="h-5 w-5 text-white" />
            </div>
            <div className="text-left">
              <span className="block text-sm font-bold leading-tight text-white">
                TubeFactory<span className="tf-gradient-text">AI</span>
              </span>
              <span className="block text-[10px] leading-tight text-slate-500">6 Engines · 1 System</span>
            </div>
          </button>

          {/* Desktop Nav */}
          <nav className="hidden items-center gap-1 lg:flex">
            <button
              onClick={() => navigate('home')}
              className={`rounded-lg px-4 py-2 text-sm font-medium transition-colors ${view === 'home' ? 'text-cyan-400' : 'text-slate-400 hover:text-white'}`}
            >
              Home
            </button>
            {navItems.map((e) => (
              <button
                key={e.id}
                onClick={() => navigate(e.id)}
                className={`rounded-lg px-4 py-2 text-sm font-medium transition-colors ${view === e.id ? 'text-cyan-400' : 'text-slate-400 hover:text-white'}`}
              >
                {e.title.replace(' Factory', '').replace(' System', '').replace(' Brain', '')}
              </button>
            ))}
          </nav>

          {/* Mobile Toggle */}
          <button
            onClick={() => setMobileNav(!mobileNav)}
            className="rounded-lg p-2 text-slate-400 hover:text-white lg:hidden"
          >
            {mobileNav ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Nav */}
        {mobileNav && (
          <nav className="border-t border-slate-800 bg-[#0a0e1a] px-4 py-3 lg:hidden">
            <div className="space-y-1">
              <button
                onClick={() => navigate('home')}
                className="block w-full rounded-lg px-4 py-2 text-left text-sm font-medium text-slate-300 hover:bg-slate-800"
              >
                Home
              </button>
              {navItems.map((e) => (
                <button
                  key={e.id}
                  onClick={() => navigate(e.id)}
                  className="block w-full rounded-lg px-4 py-2 text-left text-sm font-medium text-slate-300 hover:bg-slate-800"
                >
                  {e.title}
                </button>
              ))}
            </div>
          </nav>
        )}
      </header>

      {/* Content */}
      {view === 'home' ? (
        <div className="tf-grid-bg">
          {/* Hero */}
          <section className="relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-b from-cyan-500/5 via-transparent to-transparent" />
            <div className="absolute left-1/2 top-0 h-[400px] w-[600px] -translate-x-1/2 rounded-full bg-cyan-500/10 blur-[120px]" />
            <div className="relative mx-auto max-w-7xl px-4 py-20 text-center sm:px-6 sm:py-28">
              <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-cyan-500/30 bg-cyan-500/10 px-4 py-2 text-xs font-semibold text-cyan-400">
                <Sparkles className="h-4 w-4" />
                The World's First All-in-One YouTube & Business UGC Factory · Now with AI Video Generation
              </div>
              <h1 className="mx-auto max-w-4xl text-4xl font-bold leading-tight text-white sm:text-6xl">
                Six Engines. <span className="tf-gradient-text">One System.</span><br />
                Endless Content.
              </h1>
              <p className="mx-auto mt-6 max-w-2xl text-lg text-slate-400">
                Generate viral YouTube videos, ultra-realistic UGC ads, auto-edited content with virality scores,
                business ad campaigns, and dynamic geo-based pricing — all from one platform.
              </p>
              <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
                <button
                  onClick={() => navigate('ugc')}
                  className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 px-8 py-4 text-base font-bold text-slate-900 transition-all hover:scale-[1.02] hover:shadow-lg hover:shadow-amber-500/30"
                >
                  <Play className="h-5 w-5" /> Start with UGC Ads
                </button>
                <button
                  onClick={() => navigate('youtube')}
                  className="inline-flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-800/50 px-8 py-4 text-base font-semibold text-slate-200 transition-all hover:border-cyan-500/50 hover:bg-slate-800"
                >
                  <Youtube className="h-5 w-5" /> YouTube Factory
                </button>
              </div>

              {/* Stats */}
              <div className="mx-auto mt-16 grid max-w-3xl grid-cols-2 gap-4 sm:grid-cols-4">
                {[
                  { label: 'Engines', value: '6' },
                  { label: 'Base 4K', value: '$500' },
                  { label: 'Max Duration', value: '30s' },
                  { label: 'Languages', value: String(LANGUAGES.length) },
                ].map((stat) => (
                  <div key={stat.label} className="rounded-xl border border-slate-800 bg-slate-900/50 p-4">
                    <p className="text-2xl font-bold text-cyan-400">{stat.value}</p>
                    <p className="text-xs text-slate-500">{stat.label}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* Engines Grid */}
          <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
            <div className="mb-10 text-center">
              <h2 className="text-3xl font-bold text-white">Choose Your Engine</h2>
              <p className="mt-2 text-slate-400">Each engine is a complete production pipeline</p>
            </div>

            <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
              {engines.map((engine) => (
                <button
                  key={engine.id}
                  onClick={() => navigate(engine.id)}
                  className="group relative overflow-hidden rounded-2xl border border-slate-700/80 bg-[#151b2e]/80 p-6 text-left tf-card-hover"
                >
                  {engine.tag && (
                    <span className="absolute right-4 top-4 rounded-full border border-amber-500/30 bg-amber-500/10 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-amber-400">
                      {engine.tag}
                    </span>
                  )}
                  <div className={`mb-4 flex h-14 w-14 items-center justify-center rounded-xl bg-gradient-to-br ${engine.gradient} text-white`}>
                    {engine.icon}
                  </div>
                  <div className="mb-1 text-xs font-bold text-slate-600">ENGINE {engine.number}</div>
                  <h3 className="mb-2 text-lg font-bold text-white">{engine.title}</h3>
                  <p className="text-sm text-slate-400">{engine.description}</p>
                  <div className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-cyan-400 transition-transform group-hover:translate-x-1">
                    Launch <ArrowRight className="h-4 w-4" />
                  </div>
                </button>
              ))}

              {/* CTA Card */}
              <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-slate-700 bg-slate-900/30 p-6 text-center">
                <Globe className="mb-3 h-10 w-10 text-slate-600" />
                <h3 className="mb-1 font-semibold text-white">{LANGUAGES.length}-Language Voiceover</h3>
                <p className="text-sm text-slate-400">
                  {LANGUAGES.slice(0, 6).map((l) => l.label).join(' · ')}
                  {LANGUAGES.length > 6 && ` · +${LANGUAGES.length - 6} more`}
                </p>
              </div>
            </div>
          </section>

          {/* Pricing Preview */}
          <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
            <div className="rounded-2xl border border-slate-700/80 bg-[#151b2e]/80 p-8 tf-glow">
              <div className="grid gap-8 lg:grid-cols-2">
                <div>
                  <div className="mb-2 inline-flex items-center gap-2 text-xs font-semibold text-amber-400">
                    <ShieldCheck className="h-4 w-4" /> TRANSPARENT PRICING
                  </div>
                  <h2 className="text-2xl font-bold text-white">Dynamic Pricing Brain</h2>
                  <p className="mt-3 text-slate-400">
                    Pay-per-second for UGC ads. No packages. Geo-based multipliers auto-detect your location
                    for fair regional pricing. 1 Credit = $1 USD.
                  </p>
                  <div className="mt-6 space-y-2">
                    {[
                      { label: 'USA Client — 10s, 4K, Clothing, Sales', price: '$1,125' },
                      { label: 'Pakistan Client — Same video', price: '$393' },
                      { label: 'UAE Client — Same video', price: '$787' },
                    ].map((row) => (
                      <div key={row.label} className="flex items-center justify-between rounded-xl border border-slate-700 bg-slate-800/50 p-3">
                        <span className="text-sm text-slate-300">{row.label}</span>
                        <span className="font-bold text-amber-400">{row.price}</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="flex flex-col items-center justify-center gap-4 rounded-xl bg-gradient-to-br from-slate-800/80 to-slate-900/80 p-8">
                  <p className="text-sm text-slate-400">Base locked price</p>
                  <p className="text-5xl font-bold tf-gradient-text">$500</p>
                  <p className="text-sm text-slate-400">4K · 10 seconds</p>
                  <button
                    onClick={() => navigate('pricing')}
                    className="mt-4 inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 px-6 py-3 text-sm font-semibold text-white transition-all hover:scale-[1.02] hover:shadow-lg hover:shadow-cyan-500/30"
                  >
                    <Brain className="h-4 w-4" /> Open Pricing Calculator
                  </button>
                </div>
              </div>
            </div>
          </section>

          {/* Footer */}
          <footer className="border-t border-slate-800/60 py-8">
            <div className="mx-auto max-w-7xl px-4 text-center sm:px-6">
              <div className="flex items-center justify-center gap-2">
                <Zap className="h-5 w-5 text-cyan-400" />
                <span className="font-bold text-white">TubeFactory<span className="tf-gradient-text">AI</span>.com</span>
              </div>
              <p className="mt-2 text-xs text-slate-500">The World's First All-in-One YouTube & Business UGC Factory · 6 Engines in 1 System</p>
            </div>
          </footer>
        </div>
      ) : (
        <main className="mx-auto max-w-5xl px-4 py-8 sm:px-6 sm:py-12">
          <button
            onClick={() => navigate('home')}
            className="mb-6 inline-flex items-center gap-1 text-sm text-slate-400 transition-colors hover:text-cyan-400"
          >
            <ArrowRight className="h-4 w-4 rotate-180" /> Back to all engines
          </button>
          <div key={view} className="tf-fade-in">
            {renderEngine()}
          </div>
        </main>
      )}
    </div>
  );
}
