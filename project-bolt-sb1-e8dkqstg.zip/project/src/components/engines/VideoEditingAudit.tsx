import { useState } from 'react';
import { Scissors, Gauge, TrendingUp, Image as ImageIcon, Loader2, Check, Star, AlertTriangle } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { LANGUAGES } from '@/lib/languages';

interface AuditResult {
  hookScore: number;
  retentionScore: number;
  viralityScore: number;
  suggestedHooks: string[];
  thumbnails: { title: string; gradient: string }[];
}

export function VideoEditingAudit() {
  const [url, setUrl] = useState('');
  const [captionLang, setCaptionLang] = useState('English');
  const [editing, setEditing] = useState(false);
  const [result, setResult] = useState<AuditResult | null>(null);
  const [stage, setStage] = useState('');

  const stages = [
    'Analyzing video timeline...',
    'Auto-cutting silence...',
    'Applying auto-zoom...',
    'Generating captions...',
    'Scoring hook, retention, virality...',
    'Generating viral thumbnails...',
  ];

  const handleAnalyze = async () => {
    if (!url.trim()) return;
    setEditing(true);
    setResult(null);

    for (const s of stages) {
      setStage(s);
      await new Promise((r) => setTimeout(r, 500));
    }

    const hookScore = Math.floor(Math.random() * 4) + 5;
    const retentionScore = Math.floor(Math.random() * 4) + 5;
    const viralityScore = Math.floor(Math.random() * 4) + 5;

    const needsBetterHooks = hookScore < 7;

    setResult({
      hookScore,
      retentionScore,
      viralityScore,
      suggestedHooks: needsBetterHooks
        ? [
            `This ${url.includes('how') ? 'method' : 'thing'} changed everything in 24 hours...`,
            `I was today years old when I learned this about...`,
            `Stop doing THIS if you want to actually succeed`,
          ]
        : [],
      thumbnails: [
        { title: 'Shocked Face + Bold Text', gradient: 'from-rose-500 to-orange-500' },
        { title: 'Before/After Split', gradient: 'from-cyan-500 to-blue-500' },
        { title: 'Question + Arrow Point', gradient: 'from-amber-400 to-amber-600' },
      ],
    });

    setEditing(false);
    setStage('');
  };

  const renderScore = (label: string, score: number, icon: React.ReactNode, color: string) => (
    <div className="flex flex-col items-center gap-2 rounded-xl border border-slate-700 bg-slate-800/50 p-5">
      <div className="flex items-center gap-2 text-slate-400">
        {icon}
        <span className="text-xs font-semibold uppercase tracking-wide">{label}</span>
      </div>
      <div className={`text-4xl font-bold ${color}`}>
        {score}
        <span className="text-lg text-slate-500">/10</span>
      </div>
      <div className="h-2 w-full overflow-hidden rounded-full bg-slate-700">
        <div
          className={`h-full rounded-full ${score >= 7 ? 'bg-emerald-500' : 'bg-amber-500'}`}
          style={{ width: `${score * 10}%` }}
        />
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600">
          <Scissors className="h-6 w-6 text-white" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-white">Video Editing & Audit</h2>
          <p className="text-sm text-slate-400">Auto-edit, score, and optimize for virality</p>
        </div>
      </div>

      <Card className="p-6" glow>
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-300">Video URL or Title</label>
            <input
              type="text"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="Paste YouTube/video URL"
              className="w-full rounded-xl border border-slate-700 bg-slate-800/80 px-4 py-3 text-sm text-slate-200 placeholder:text-slate-500 transition-colors hover:border-cyan-500/50 focus:border-cyan-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/20"
            />
          </div>

          <div className="space-y-3">
            <div className="flex flex-wrap gap-2">
              {['Auto-Cut Silence', 'Auto-Zoom', 'Audit Score'].map((f) => (
                <Badge key={f} variant="accent">{f}</Badge>
              ))}
            </div>
            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-300">Caption Language</label>
              <div className="flex flex-wrap gap-1.5">
                {LANGUAGES.map((lang) => (
                  <button
                    key={lang.value}
                    onClick={() => setCaptionLang(lang.value)}
                    className={`rounded-lg border px-3 py-1.5 text-xs font-medium transition-all ${
                      captionLang === lang.value
                        ? 'border-cyan-500 bg-cyan-500/10 text-cyan-400'
                        : 'border-slate-700 bg-slate-800/50 text-slate-400 hover:border-slate-600'
                    }`}
                  >
                    {lang.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <Button onClick={handleAnalyze} disabled={!url.trim() || editing} size="lg" fullWidth>
            {editing ? (
              <><Loader2 className="h-5 w-5 animate-spin" /> Processing...</>
            ) : (
              <><Gauge className="h-5 w-5" /> Edit & Audit Video</>
            )}
          </Button>
        </div>
      </Card>

      {editing && (
        <Card className="p-6 tf-fade-in">
          <div className="space-y-3">
            {stages.map((s, i) => {
              const currentIdx = stages.indexOf(stage);
              const done = i < currentIdx;
              const current = i === currentIdx;
              return (
                <div key={s} className={`flex items-center gap-3 text-sm transition-opacity ${current || done ? 'opacity-100' : 'opacity-30'}`}>
                  {done ? <Check className="h-5 w-5 text-emerald-400" /> : current ? <Loader2 className="h-5 w-5 animate-spin text-cyan-400" /> : <div className="h-5 w-5 rounded-full border-2 border-slate-700" />}
                  <span className={done ? 'text-slate-500' : current ? 'text-cyan-400' : 'text-slate-600'}>{s}</span>
                </div>
              );
            })}
          </div>
        </Card>
      )}

      {result && !editing && (
        <div className="space-y-4 tf-fade-in">
          <div className="grid gap-4 sm:grid-cols-3">
            {renderScore('Hook', result.hookScore, <TrendingUp className="h-4 w-4" />, result.hookScore >= 7 ? 'text-emerald-400' : 'text-amber-400')}
            {renderScore('Retention', result.retentionScore, <Gauge className="h-4 w-4" />, result.retentionScore >= 7 ? 'text-emerald-400' : 'text-amber-400')}
            {renderScore('Virality', result.viralityScore, <Star className="h-4 w-4" />, result.viralityScore >= 7 ? 'text-emerald-400' : 'text-amber-400')}
          </div>

          {result.suggestedHooks.length > 0 && (
            <Card className="border-amber-500/30 p-5 tf-glow-gold">
              <div className="mb-3 flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-amber-400" />
                <h4 className="font-semibold text-white">Hook score below 7 — 3 better hooks suggested</h4>
              </div>
              <div className="space-y-2">
                {result.suggestedHooks.map((hook, i) => (
                  <div key={i} className="flex items-start gap-3 rounded-xl border border-slate-700 bg-slate-800/50 p-3">
                    <span className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full bg-amber-500/20 text-xs font-bold text-amber-400">{i + 1}</span>
                    <p className="text-sm text-slate-200">{hook}</p>
                  </div>
                ))}
              </div>
            </Card>
          )}

          <Card className="p-5">
            <div className="mb-3 flex items-center gap-2">
              <ImageIcon className="h-4 w-4 text-cyan-400" />
              <h4 className="font-semibold text-white">Viral Thumbnail Generator</h4>
            </div>
            <div className="grid gap-3 sm:grid-cols-3">
              {result.thumbnails.map((thumb, i) => (
                <div key={i} className="group cursor-pointer overflow-hidden rounded-xl border border-slate-700 tf-card-hover">
                  <div className={`flex h-32 items-center justify-center bg-gradient-to-br ${thumb.gradient}`}>
                    <span className="text-xs font-bold text-white/90">Preview {i + 1}</span>
                  </div>
                  <div className="p-3">
                    <p className="text-sm text-slate-300">{thumb.title}</p>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}
