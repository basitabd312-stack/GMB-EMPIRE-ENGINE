export type Quality = '1080p' | '3K' | '4K';
export type BusinessCategory = 'Small/General/Salon' | 'Restaurant' | 'Clothing/Ecom' | 'Real Estate/Cars';
export type ScriptType = 'Review' | 'Demo' | 'High Sales';
export type GeoTier = 'Tier 1' | 'Middle East' | 'Pakistan/India/BD';

export interface QualityRate {
  '1080p': number;
  '3K': number;
  '4K': number;
}

export const QUALITY_RATES: QualityRate = {
  '1080p': 28,
  '3K': 45,
  '4K': 50,
};

export const BUSINESS_MULTIPLIERS: Record<BusinessCategory, number> = {
  'Small/General/Salon': 1.0,
  'Restaurant': 1.2,
  'Clothing/Ecom': 1.5,
  'Real Estate/Cars': 2.0,
};

export const SCRIPT_MULTIPLIERS: Record<ScriptType, number> = {
  'Review': 1.0,
  'Demo': 1.3,
  'High Sales': 1.5,
};

export const GEO_MULTIPLIERS: Record<GeoTier, number> = {
  'Tier 1': 1.0,
  'Middle East': 0.7,
  'Pakistan/India/BD': 0.35,
};

export const GEO_COUNTRIES: Record<GeoTier, string[]> = {
  'Tier 1': ['United States', 'United Kingdom', 'Canada', 'Australia', 'Germany', 'France', 'Netherlands', 'Sweden', 'Norway', 'Denmark', 'Finland', 'Switzerland', 'Ireland', 'New Zealand', 'Belgium', 'Austria', 'Luxembourg'],
  'Middle East': ['United Arab Emirates', 'Saudi Arabia', 'Qatar', 'Kuwait', 'Bahrain', 'Oman', 'Egypt', 'Jordan', 'Lebanon', 'Iraq'],
  'Pakistan/India/BD': ['Pakistan', 'India', 'Bangladesh', 'Sri Lanka', 'Nepal'],
};

export const MEMBERSHIP_PRICES: Record<GeoTier, number> = {
  'Tier 1': 120,
  'Middle East': 80,
  'Pakistan/India/BD': 50,
};

export interface PricingInput {
  seconds: number;
  quality: Quality;
  businessCategory: BusinessCategory;
  scriptType: ScriptType;
  geoTier: GeoTier;
  country: string;
}

export interface PricingResult {
  seconds: number;
  quality: Quality;
  businessCategory: BusinessCategory;
  scriptType: ScriptType;
  geoTier: GeoTier;
  country: string;
  qualityRate: number;
  businessMultiplier: number;
  scriptMultiplier: number;
  geoMultiplier: number;
  finalCredits: number;
  formula: string;
}

export function calculatePricing(input: PricingInput): PricingResult {
  const qualityRate = QUALITY_RATES[input.quality];
  const businessMultiplier = BUSINESS_MULTIPLIERS[input.businessCategory];
  const scriptMultiplier = SCRIPT_MULTIPLIERS[input.scriptType];
  const geoMultiplier = GEO_MULTIPLIERS[input.geoTier];

  const finalCredits = Math.round(
    input.seconds * qualityRate * businessMultiplier * scriptMultiplier * geoMultiplier
  );

  const formula = `${input.seconds} × ${qualityRate} × ${businessMultiplier} × ${scriptMultiplier} × ${geoMultiplier} = ${finalCredits}`;

  return {
    ...input,
    qualityRate,
    businessMultiplier,
    scriptMultiplier,
    geoMultiplier,
    finalCredits,
    formula,
  };
}

export function getGeoTierForCountry(country: string): GeoTier {
  for (const [tier, countries] of Object.entries(GEO_COUNTRIES)) {
    if (countries.some((c) => c.toLowerCase() === country.toLowerCase())) {
      return tier as GeoTier;
    }
  }
  return 'Tier 1';
}
