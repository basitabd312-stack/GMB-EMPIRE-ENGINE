export interface LanguageOption {
  value: string;
  label: string;
  nativeName: string;
  flag: string;
}

export const LANGUAGES: LanguageOption[] = [
  { value: 'English', label: 'English', nativeName: 'English', flag: 'GB' },
  { value: 'Urdu', label: 'Urdu', nativeName: 'اردو', flag: 'PK' },
  { value: 'Arabic', label: 'Arabic', nativeName: 'العربية', flag: 'SA' },
  { value: 'Hindi', label: 'Hindi', nativeName: 'हिन्दी', flag: 'IN' },
  { value: 'Bengali', label: 'Bengali', nativeName: 'বাংলা', flag: 'BD' },
  { value: 'Spanish', label: 'Spanish', nativeName: 'Español', flag: 'ES' },
  { value: 'French', label: 'French', nativeName: 'Français', flag: 'FR' },
  { value: 'German', label: 'German', nativeName: 'Deutsch', flag: 'DE' },
  { value: 'Portuguese', label: 'Portuguese', nativeName: 'Português', flag: 'PT' },
  { value: 'Turkish', label: 'Turkish', nativeName: 'Türkçe', flag: 'TR' },
  { value: 'Indonesian', label: 'Indonesian', nativeName: 'Indonesia', flag: 'ID' },
  { value: 'Russian', label: 'Russian', nativeName: 'Русский', flag: 'RU' },
  { value: 'Chinese', label: 'Chinese', nativeName: '中文', flag: 'CN' },
  { value: 'Japanese', label: 'Japanese', nativeName: '日本語', flag: 'JP' },
  { value: 'Korean', label: 'Korean', nativeName: '한국어', flag: 'KR' },
  { value: 'Persian', label: 'Persian', nativeName: 'فارسی', flag: 'IR' },
  { value: 'Punjabi', label: 'Punjabi', nativeName: 'ਪੰਜਾਬੀ', flag: 'IN' },
  { value: 'Pashto', label: 'Pashto', nativeName: 'پښتو', flag: 'AF' },
  { value: 'Malay', label: 'Malay', nativeName: 'Melayu', flag: 'MY' },
  { value: 'Thai', label: 'Thai', nativeName: 'ไทย', flag: 'TH' },
  { value: 'Vietnamese', label: 'Vietnamese', nativeName: 'Tiếng Việt', flag: 'VN' },
  { value: 'Italian', label: 'Italian', nativeName: 'Italiano', flag: 'IT' },
  { value: 'Dutch', label: 'Dutch', nativeName: 'Nederlands', flag: 'NL' },
  { value: 'Polish', label: 'Polish', nativeName: 'Polski', flag: 'PL' },
];

export const LANGUAGE_SELECT_OPTIONS = LANGUAGES.map((l) => ({
  value: l.value,
  label: `${l.label} (${l.nativeName})`,
}));
