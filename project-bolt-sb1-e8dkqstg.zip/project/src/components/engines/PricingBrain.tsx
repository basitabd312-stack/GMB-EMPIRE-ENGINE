import { useState } from 'react';
import { Brain, Calculator, DollarSign, Globe, Check } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import {
  QUALITY_RATES,
  BUSINESS_MULTIPLIERS,
  SCRIPT_MULTIPLIERS,
  GEO_MULTIPLIERS,
  MEMBERSHIP_PRICES,
  calculatePricing,
  getGeoTierForCountry,
  type Quality,
  type BusinessCategory,
  type ScriptType,
  type GeoTier,
  GEO_COUNTRIES,
} from '@/lib/pricing';

export function PricingBrain() {
  const [seconds, setSeconds] = useState(10);
  const [quality, setQuality] = useState<Quality>('4K');
  const [category, setCategory] = useState<BusinessCategory>('Clothing/Ecom');
  const [scriptType, setScriptType] = useState<ScriptType>('High Sales');
  const [country, setCountry] = useState('United States');
  const [showResult, setShowResult] = useState(false);

  const geoTier = getGeoTierForCountry(country);
  const result = calculatePricing({ seconds, quality, businessCategory: category, scriptType, geoTier, country });

  const allCountries = Object.values(GEO_COUNTRIES).flat();

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500 to-fuchsia-600">
          <Brain className="h-6 w-6 text-white" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-white">Dynamic Pricing Brain</h2>
          <p className="text-sm text-slate-400">Live pricing calculator · 1 Credit = $1 USD</p>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Inputs */}
        <Card className="p-6" glow>
          <div className="space-y-5">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium text-slate-300">Duration</label>
                <span className="rounded-lg bg-cyan-500/10 px-3 py-1 text-sm font-bold text-cyan-400">{seconds} sec</span>
              </div>
              <input
                type="range"
                min={5}
                max={30}
                value={seconds}
                onChange={(e) => { setSeconds(Number(e.target.value)); setShowResult(false); }}
                className="tf-range w-full"
              />
              <div className="flex justify-between text-xs text-slate-500">
                <span>5 sec</span><span>30 sec</span>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-300">Quality</label>
              <div className="grid grid-cols-3 gap-2">
                {(Object.keys(QUALITY_RATES) as Quality[]).map((q) => (
                  <button
                    key={q}
                    onClick={() => { setQuality(q); setShowResult(false); }}
                    className={`rounded-xl border p-3 text-center transition-all ${quality === q ? 'border-cyan-500 bg-cyan-500/10 tf-glow' : 'border-slate-700 bg-slate-800/50 hover:border-cyan-500/50'}`}
                  >
                    <p className="text-sm font-bold text-white">{q}</p>
                    <p className="text-xs text-slate-400">${QUALITY_RATES[q]}/s</p>
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-300">Business Category</label>
              <div className="grid grid-cols-2 gap-2">
                {(Object.keys(BUSINESS_MULTIPLIERS) as BusinessCategory[]).map((cat) => (
                  <button
                    key={cat}
                    onClick={() => { setCategory(cat); setShowResult(false); }}
                    className={`rounded-xl border p-3 text-left transition-all ${category === cat ? 'border-cyan-500 bg-cyan-500/10' : 'border-slate-700 bg-slate-800/50 hover:border-cyan-500/50'}`}
                  >
                    <p className="text-xs font-semibold text-white">{cat}</p>
                    <p className="text-xs text-cyan-400">{BUSINESS_MULTIPLIERS[cat]}x</p>
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-300">Script Type</label>
              <div className="grid grid-cols-3 gap-2">
                {(Object.keys(SCRIPT_MULTIPLIERS) as ScriptType[]).map((st) => (
                  <button
                    key={st}
                    onClick={() => { setScriptType(st); setShowResult(false); }}
                    className={`rounded-xl border p-3 text-center transition-all ${scriptType === st ? 'border-cyan-500 bg-cyan-500/10' : 'border-slate-700 bg-slate-800/50 hover:border-cyan-500/50'}`}
                  >
                    <p className="text-xs font-bold text-white">{st}</p>
                    <p className="text-xs text-cyan-400">{SCRIPT_MULTIPLIERS[st]}x</p>
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-300">
                <Globe className="mr-1 inline h-4 w-4 text-cyan-400" />
                Location (Auto IP Detect)
              </label>
              <select
                value={country}
                onChange={(e) => { setCountry(e.target.value); setShowResult(false); }}
                className="w-full appearance-none rounded-xl border border-slate-700 bg-slate-800/80 px-4 py-3 text-sm text-slate-200 transition-colors hover:border-cyan-500/50 focus:border-cyan-500 focus:outline-none"
              >
                {allCountries.map((c) => (
                  <option key={c} value={c} className="bg-slate-800">{c}</option>
                ))}
              </select>
              <Badge variant="accent">{geoTier} · {GEO_MULTIPLIERS[geoTier]}x</Badge>
            </div>

            <Button fullWidth size="lg" onClick={() => setShowResult(true)}>
              <Calculator className="h-5 w-5" /> Calculate Final Price
            </Button>
          </div>
        </Card>

        {/* Result */}
        <div className="space-y-4">
          <Card className="p-6 tf-glow" glow>
            <div className="mb-4 flex items-center gap-2">
              <DollarSign className="h-5 w-5 text-amber-400" />
              <h3 className="font-semibold text-white">Price Breakdown</h3>
            </div>

            <div className="space-y-2 text-sm">
              <div className="flex justify-between border-b border-slate-700/50 pb-2">
                <span className="text-slate-400">Seconds</span>
                <span className="font-semibold text-white">{result.seconds}</span>
              </div>
              <div className="flex justify-between border-b border-slate-700/50 pb-2">
                <span className="text-slate-400">Quality Rate ({result.quality})</span>
                <span className="font-semibold text-white">${result.qualityRate}/sec</span>
              </div>
              <div className="flex justify-between border-b border-slate-700/50 pb-2">
                <span className="text-slate-400">Business ({result.businessCategory})</span>
                <span className="font-semibold text-white">{result.businessMultiplier}x</span>
              </div>
              <div className="flex justify-between border-b border-slate-700/50 pb-2">
                <span className="text-slate-400">Script ({result.scriptType})</span>
                <span className="font-semibold text-white">{result.scriptMultiplier}x</span>
              </div>
              <div className="flex justify-between border-b border-slate-700/50 pb-2">
                <span className="text-slate-400">Geo ({result.country})</span>
                <span className="font-semibold text-white">{result.geoMultiplier}x</span>
              </div>
            </div>

            <div className="mt-4 rounded-xl bg-slate-800/80 p-3 text-center">
              <p className="font-mono text-xs text-slate-400">{result.formula}</p>
            </div>

            {showResult && (
              <div className="mt-4 tf-scale-in">
                <div className="rounded-xl bg-gradient-to-r from-amber-500/20 to-orange-500/20 p-6 text-center tf-glow-gold">
                  <p className="text-xs uppercase tracking-wide text-amber-400">Final Price</p>
                  <p className="mt-2 text-4xl font-bold text-amber-400">
                    {result.finalCredits}
                  </p>
                  <p className="mt-1 text-sm text-slate-300">
                    Credits = ${result.finalCredits} USD
                  </p>
                </div>
                <p className="mt-3 text-center text-sm text-slate-400">
                  {result.finalCredits} Credits will be deducted. Generate? <span className="font-semibold text-cyan-400">Yes / No</span>
                </p>
              </div>
            )}
          </Card>

          {/* Quick Reference */}
          <Card className="p-5">
            <h4 className="mb-3 text-sm font-semibold text-white">Quick Reference</h4>
            <div className="space-y-2 text-xs">
              <div className="flex justify-between"><span className="text-slate-400">Quality Rates</span><span className="text-slate-300">1080p: $28 · 3K: $45 · 4K: $50</span></div>
              <div className="flex justify-between"><span className="text-slate-400">Base (4K 10s)</span><span className="text-amber-400">$500 locked</span></div>
            </div>
          </Card>

          {/* Membership Prices */}
          <Card className="p-5">
            <div className="mb-3 flex items-center gap-2">
              <Check className="h-4 w-4 text-emerald-400" />
              <h4 className="text-sm font-semibold text-white">YouTube Factory Membership</h4>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {(Object.keys(MEMBERSHIP_PRICES) as GeoTier[]).map((tier) => (
                <div key={tier} className="rounded-xl border border-slate-700 bg-slate-800/50 p-3 text-center">
                  <p className="text-xs text-slate-400">{tier}</p>
                  <p className="mt-1 text-lg font-bold text-cyan-400">${MEMBERSHIP_PRICES[tier]}</p>
                </div>
              ))}
            </div>
            <p className="mt-3 text-xs text-slate-500">UGC Ads = Pay-as-you-go. No packages. Max 30s, min 5s.</p>
          </Card>
        </div>
      </div>
    </div>
  );
}
