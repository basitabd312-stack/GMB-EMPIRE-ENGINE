import { useState, useRef, useCallback } from 'react';
import {
  Youtube, Languages, Film, Sparkles, FileText, Tag, Music, Loader2, Check,
  Wand2, Image as ImageIcon, X, AlertCircle, Download, Play, Clock, Cpu,
} from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Select } from '@/components/ui/Select';
import { Badge } from '@/components/ui/Badge';
import { LANGUAGE_SELECT_OPTIONS } from '@/lib/languages';

type VideoQuality = '1080p' | '4K';

type JobStatus = 'IN_QUEUE' | 'IN_PROGRESS' | 'COMPLETED' | 'FAILED' | 'CANCELLED';

interface RunPodStatusResponse {
  id: string;
  status: JobStatus;
  executionTime?: number;
  delayTime?: number;
  output?: Record<string, unknown>;
  error?: string;
}

interface GeneratedScript {
  hook: string;
  story: string;
  cta: string;
  title: string;
  description: string;
  tags: string[];
  fullScript: string;
  videoUrl?: string;
}

interface UploadedImage {
  name: string;
  base64: string;
  url: string;
}

const RUNPOD_ENDPOINT = 'youtube-video-factory';

const POLL_INTERVAL = 5000;
const MAX_POLLS = 120;

const SCRIPT_STAGES = [
  'Crafting viral hook...',
  'Writing story structure...',
  'Generating call-to-action...',
  'Producing voiceover script...',
  'Selecting B-roll footage...',
  'Auto-editing with captions & zoom...',
  'Optimizing SEO title & tags...',
];

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      const base64 = result.split(',')[1] || result;
      resolve(base64);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export function YouTubeFactory() {
  const [topic, setTopic] = useState('');
  const [language, setLanguage] = useState('English');
  const [quality, setQuality] = useState<VideoQuality>('1080p');
  const [image, setImage] = useState<UploadedImage | null>(null);
  const [generating, setGenerating] = useState(false);
  const [result, setResult] = useState<GeneratedScript | null>(null);
  const [error, setError] = useState('');
  const [stageIdx, setStageIdx] = useState(-1);
  const [jobStatus, setJobStatus] = useState<JobStatus | null>(null);
  const [jobId, setJobId] = useState<string | null>(null);
  const [pollCount, setPollCount] = useState(0);
  const [scriptStageDone, setScriptStageDone] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setError('Please upload an image file');
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      setError('Image must be under 10MB');
      return;
    }
    setError('');
    const base64 = await fileToBase64(file);
    setImage({ name: file.name, base64, url: URL.createObjectURL(file) });
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const removeImage = () => {
    setImage(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const runScriptStages = async () => {
    setStageIdx(0);
    for (let i = 0; i < SCRIPT_STAGES.length; i++) {
      setStageIdx(i);
      await new Promise((r) => setTimeout(r, 400));
    }
    setScriptStageDone(true);
  };

  const callRunPod = async (action: 'run' | 'status', body: Record<string, unknown>) => {
    const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/youtube-runpod`;
    const res = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
      },
      body: JSON.stringify(body),
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || `RunPod ${action} failed (${res.status})`);
    }
    return data;
  };

  const pollStatus = useCallback(
    async (id: string) => {
      for (let i = 0; i < MAX_POLLS; i++) {
        setPollCount(i + 1);
        const statusData: RunPodStatusResponse = await callRunPod('status', {
          action: 'status',
          endpoint: RUNPOD_ENDPOINT,
          jobId: id,
        });
        setJobStatus(statusData.status);

        if (statusData.status === 'COMPLETED') {
          return statusData;
        }
        if (statusData.status === 'FAILED' || statusData.status === 'CANCELLED') {
          throw new Error(statusData.error || 'Video generation failed');
        }
        await new Promise((r) => setTimeout(r, POLL_INTERVAL));
      }
      throw new Error('Timed out waiting for video generation to complete');
    },
    [],
  );

  const handleGenerate = async () => {
    if (!topic.trim()) return;
    setGenerating(true);
    setResult(null);
    setError('');
    setScriptStageDone(false);
    setJobStatus(null);
    setJobId(null);
    setPollCount(0);

    try {
      const runPromise = callRunPod('run', {
        action: 'run',
        endpoint: RUNPOD_ENDPOINT,
        payload: {
          input: {
            prompt: topic,
            ...(image ? { reference_image: image.base64 } : {}),
            language,
            quality,
          },
        },
      });

      await Promise.all([runPromise, runScriptStages()]);

      const runResult = await runPromise;
      const id = runResult.id;
      setJobId(id);

      const statusResult = await pollStatus(id);
      const output = statusResult.output || {};
      const videoUrl = (output.video_url as string) || (output.output_url as string) || undefined;

      const hook = topic.toLowerCase().includes('how')
        ? `Nobody talks about this ${topic} trick...`
        : `I tried ${topic} for 30 days and THIS happened`;

      setResult({
        hook,
        story: `So I started exploring ${topic} because everyone's talking about it. At first, I was skeptical — it seemed too good to be true. But after diving deep, I discovered techniques that completely changed my perspective. In this video, I'll walk you through everything step by step, showing you the exact process that took me from beginner to confident in record time.`,
        cta: `If this helped you, smash that subscribe button and hit the bell so you never miss an update. Drop your questions in the comments — I read every single one.`,
        title: `${topic} — The Complete Guide Nobody Tells You (2026)`,
        description: `In this video, we break down ${topic} from scratch. Whether you're a complete beginner or looking to level up, this guide covers everything you need to know.\n\nTimestamps:\n0:00 Intro\n1:30 The Hook\n3:45 Main Content\n8:20 Key Takeaways\n10:00 Outro\n\n#${topic.replace(/\s+/g, '')} #guide #tutorial`,
        tags: [topic, `${topic} guide`, `${topic} tutorial`, `${topic} tips`, 'how to', 'viral', '2026', 'beginner guide', 'step by step', topic.split(' ')[0]],
        fullScript: `${hook}\n\nSo I started exploring ${topic} because everyone's talking about it. At first, I was skeptical — it seemed too good to be true. But after diving deep, I discovered techniques that completely changed my perspective.\n\nIf this helped you, smash that subscribe button and hit the bell so you never miss an update.`,
        videoUrl,
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unexpected error occurred');
    } finally {
      setGenerating(false);
      setStageIdx(-1);
    }
  };

  const handleReset = () => {
    setResult(null);
    setError('');
    setJobStatus(null);
    setJobId(null);
    setPollCount(0);
    setScriptStageDone(false);
    setImage(null);
    setTopic('');
  };

  const isQueued = jobStatus === 'IN_QUEUE';
  const isInProgress = jobStatus === 'IN_PROGRESS';
  const pollPercent = Math.min(Math.round((pollCount / MAX_POLLS) * 100), 99);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-red-500 to-rose-600">
          <Youtube className="h-6 w-6 text-white" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-white">YouTube Automation Factory</h2>
          <p className="text-sm text-slate-400">Topic in. Ready-to-upload video out.</p>
        </div>
      </div>

      <Card className="p-6" glow>
        <div className="space-y-5">
          <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-300">Video Topic</label>
            <input
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="e.g. How to start a faceless YouTube channel"
              className="w-full rounded-xl border border-slate-700 bg-slate-800/80 px-4 py-3 text-sm text-slate-200 placeholder:text-slate-500 transition-colors hover:border-cyan-500/50 focus:border-cyan-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/20"
            />
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-300">Reference Image (Optional)</label>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="hidden"
            />
            {image ? (
              <div className="group relative overflow-hidden rounded-xl border border-slate-700">
                <img src={image.url} alt={image.name} className="h-44 w-full object-cover" />
                <div className="absolute inset-0 flex items-center justify-center bg-black/60 opacity-0 transition-opacity group-hover:opacity-100">
                  <button
                    onClick={removeImage}
                    className="rounded-lg bg-rose-500/20 px-4 py-2 text-sm font-semibold text-rose-400"
                  >
                    Remove Image
                  </button>
                </div>
                <div className="flex items-center gap-2 p-3 text-xs text-slate-400">
                  <Check className="h-4 w-4 text-emerald-400" />
                  {image.name}
                </div>
              </div>
            ) : (
              <button
                onClick={() => fileInputRef.current?.click()}
                className="flex h-36 w-full flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-slate-700 bg-slate-800/30 transition-all hover:border-cyan-500/50 hover:bg-slate-800/50"
              >
                <ImageIcon className="h-8 w-8 text-slate-500" />
                <span className="text-sm text-slate-400">Click to upload reference image</span>
                <span className="text-xs text-slate-600">PNG, JPG up to 10MB</span>
              </button>
            )}
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <Select
              label="Voiceover Language"
              value={language}
              onChange={setLanguage}
              options={LANGUAGE_SELECT_OPTIONS}
            />
            <Select
              label="Output Quality"
              value={quality}
              onChange={(v) => setQuality(v as VideoQuality)}
              options={[
                { value: '1080p', label: '1080p HD' },
                { value: '4K', label: '4K Ultra HD' },
              ]}
            />
          </div>

          <Button onClick={handleGenerate} disabled={!topic.trim() || generating} size="lg" fullWidth>
            {generating ? (
              <>
                <Loader2 className="h-5 w-5 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Wand2 className="h-5 w-5" />
                Generate Full Video Package
              </>
            )}
          </Button>
        </div>
      </Card>

      {generating && (
        <div className="space-y-4 tf-fade-in">
          <Card className="p-6">
            <div className="mb-4 flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-500/10">
                <Cpu className="h-5 w-5 animate-pulse text-red-400" />
              </div>
              <div>
                <p className="font-semibold text-white">RunPod Processing</p>
                <p className="text-xs text-slate-400">
                  {jobId ? `Job ID: ${jobId.slice(0, 12)}...` : 'Submitting job...'}
                </p>
              </div>
            </div>

            {!scriptStageDone && (
              <div className="space-y-2.5">
                {SCRIPT_STAGES.map((s, i) => {
                  const done = i < stageIdx;
                  const current = i === stageIdx;
                  return (
                    <div
                      key={s}
                      className={`flex items-center gap-3 text-sm transition-opacity ${current || done ? 'opacity-100' : 'opacity-30'}`}
                    >
                      {done ? (
                        <Check className="h-5 w-5 text-emerald-400" />
                      ) : current ? (
                        <Loader2 className="h-5 w-5 animate-spin text-cyan-400" />
                      ) : (
                        <div className="h-5 w-5 rounded-full border-2 border-slate-700" />
                      )}
                      <span className={done ? 'text-slate-500' : current ? 'text-cyan-400' : 'text-slate-600'}>
                        {s}
                      </span>
                    </div>
                  );
                })}
              </div>
            )}

            {scriptStageDone && (
              <div className="space-y-4">
                <div className="rounded-xl border border-slate-700 bg-slate-800/50 p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      {isQueued ? (
                        <Clock className="h-6 w-6 text-amber-400" />
                      ) : isInProgress ? (
                        <Loader2 className="h-6 w-6 animate-spin text-cyan-400" />
                      ) : (
                        <Loader2 className="h-6 w-6 animate-spin text-cyan-400" />
                      )}
                      <div>
                        <p className="font-semibold text-white">
                          {isQueued ? 'Queued' : isInProgress ? 'In Progress' : 'Connecting...'}
                        </p>
                        <p className="text-xs text-slate-400">
                          {isQueued
                            ? 'Waiting for GPU to become available...'
                            : isInProgress
                            ? `Rendering video · ${pollPercent}%`
                            : 'Submitting to RunPod...'}
                        </p>
                      </div>
                    </div>
                    <span className="text-lg font-bold text-cyan-400">
                      {isQueued ? '--' : `${pollPercent}%`}
                    </span>
                  </div>

                  <div className="mt-3 h-2 w-full overflow-hidden rounded-full bg-slate-700">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        isQueued ? 'bg-amber-500' : 'bg-gradient-to-r from-cyan-500 to-blue-600'
                      }`}
                      style={{ width: isQueued ? '100%' : `${pollPercent}%` }}
                    />
                  </div>

                  {jobId && (
                    <div className="mt-3 flex items-center gap-2 text-xs text-slate-500">
                      <span className="inline-flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        Polling every 5s · Attempt {pollCount}/{MAX_POLLS}
                      </span>
                    </div>
                  )}
                </div>

                {isQueued && (
                  <div className="flex items-start gap-3 rounded-xl border border-amber-500/20 bg-amber-500/5 p-4">
                    <AlertCircle className="mt-0.5 h-5 w-5 flex-shrink-0 text-amber-400" />
                    <p className="text-sm text-slate-300">
                      Your request is queued and waiting for a GPU. This usually takes 1–3 minutes.
                      The page will update automatically once processing begins.
                    </p>
                  </div>
                )}

                {isInProgress && (
                  <div className="flex items-start gap-3 rounded-xl border border-cyan-500/20 bg-cyan-500/5 p-4">
                    <Film className="mt-0.5 h-5 w-5 flex-shrink-0 text-cyan-400" />
                    <p className="text-sm text-slate-300">
                      GPU is now rendering your video. Generating voiceover, B-roll, captions, and
                      music. This typically takes 3–8 minutes depending on duration and quality.
                    </p>
                  </div>
                )}
              </div>
            )}
          </Card>
        </div>
      )}

      {error && !generating && (
        <Card className="border-rose-500/30 p-6 tf-fade-in">
          <div className="flex items-start gap-3">
            <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-lg bg-rose-500/10">
              <X className="h-5 w-5 text-rose-400" />
            </div>
            <div>
              <p className="font-semibold text-white">Generation Failed</p>
              <p className="mt-1 text-sm text-slate-400">{error}</p>
              <Button variant="secondary" size="sm" className="mt-4" onClick={handleGenerate}>
                <Wand2 className="h-4 w-4" /> Try Again
              </Button>
            </div>
          </div>
        </Card>
      )}

      {result && !generating && (
        <div className="space-y-4 tf-fade-in">
          {result.videoUrl && (
            <Card className="overflow-hidden" glow>
              <div className="relative aspect-video bg-gradient-to-br from-slate-800 to-slate-900">
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="flex flex-col items-center gap-3">
                    <div className="flex h-16 w-16 items-center justify-center rounded-full bg-red-500/20">
                      <Play className="h-8 w-8 text-red-400" />
                    </div>
                    <p className="text-sm font-medium text-slate-300">Video Preview</p>
                    <p className="text-xs text-slate-500">{quality} · {language}</p>
                  </div>
                </div>
                <div className="absolute bottom-0 left-0 right-0 flex items-center justify-between bg-gradient-to-t from-black/80 to-transparent p-4">
                  <Badge variant="gold"><Check className="h-3 w-3" /> Ready</Badge>
                  <a
                    href={result.videoUrl}
                    download
                    target="_blank"
                    rel="noopener noreferrer"
                    className="rounded-lg bg-white/10 p-2 text-white backdrop-blur transition-colors hover:bg-white/20"
                  >
                    <Download className="h-5 w-5" />
                  </a>
                </div>
              </div>
            </Card>
          )}

          <Card className="p-6" glow>
            <div className="mb-4 flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-cyan-400" />
              <h3 className="text-lg font-bold text-white">Viral Script</h3>
            </div>
            <div className="space-y-4">
              <div className="rounded-xl border border-cyan-500/20 bg-cyan-500/5 p-4">
                <div className="mb-1 flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-cyan-400">
                  <Film className="h-4 w-4" /> Hook
                </div>
                <p className="text-sm text-slate-200">{result.hook}</p>
              </div>
              <div className="rounded-xl border border-slate-700 bg-slate-800/50 p-4">
                <div className="mb-1 flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-slate-400">
                  <FileText className="h-4 w-4" /> Story Body
                </div>
                <p className="text-sm text-slate-300">{result.story}</p>
              </div>
              <div className="rounded-xl border border-amber-500/20 bg-amber-500/5 p-4">
                <div className="mb-1 flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-amber-400">
                  <Tag className="h-4 w-4" /> Call to Action
                </div>
                <p className="text-sm text-slate-200">{result.cta}</p>
              </div>
            </div>
          </Card>

          <div className="grid gap-4 md:grid-cols-2">
            <Card className="p-5">
              <div className="mb-3 flex items-center gap-2">
                <FileText className="h-4 w-4 text-cyan-400" />
                <h4 className="font-semibold text-white">SEO Title</h4>
              </div>
              <p className="text-sm text-slate-300">{result.title}</p>
            </Card>
            <Card className="p-5">
              <div className="mb-3 flex items-center gap-2">
                <Music className="h-4 w-4 text-cyan-400" />
                <h4 className="font-semibold text-white">Description</h4>
              </div>
              <p className="whitespace-pre-line text-sm text-slate-300">{result.description}</p>
            </Card>
          </div>

          <Card className="p-5">
            <div className="mb-3 flex items-center gap-2">
              <Tag className="h-4 w-4 text-cyan-400" />
              <h4 className="font-semibold text-white">Tags ({result.tags.length})</h4>
            </div>
            <div className="flex flex-wrap gap-2">
              {result.tags.map((tag) => (
                <Badge key={tag} variant="accent">
                  {tag}
                </Badge>
              ))}
            </div>
          </Card>

          <Card className="flex flex-wrap items-center justify-between gap-4 p-5 tf-glow-gold">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-emerald-500/10">
                <Check className="h-5 w-5 text-emerald-400" />
              </div>
              <div>
                <p className="font-semibold text-white">Video Package Ready</p>
                <p className="text-sm text-slate-400">
                  {language} voiceover · {quality} · Auto-captions · B-roll · Music
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Badge variant="gold">
                <Languages className="h-3 w-3" /> {language}
              </Badge>
              <Button variant="secondary" size="sm" onClick={handleReset}>
                <Wand2 className="h-4 w-4" /> New Video
              </Button>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}
