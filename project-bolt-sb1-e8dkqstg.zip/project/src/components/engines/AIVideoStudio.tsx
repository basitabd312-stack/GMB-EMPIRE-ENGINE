import { useState, useRef } from 'react';
import {
  Film, Type, Image as ImageIcon, Users, Loader2, Check, Settings2,
  Wand2, Volume2, Sparkles, Download, RefreshCw, Cpu, Clock, Monitor
} from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';

type Mode = 'text' | 'image' | 'reference';
type Resolution = '480P' | '720P' | '1080P';
type AspectRatio = 'adaptive' | '16:9' | '9:16' | '1:1';
type Duration = 'auto' | '5';

interface UploadedImage {
  name: string;
  url: string;
}

interface GenerationResult {
  prompt: string;
  mode: Mode;
  resolution: Resolution;
  duration: Duration;
  audio: boolean;
  seed: number;
}

const MODE_CONFIG: Record<Mode, { label: string; icon: React.ReactNode; description: string; gradient: string }> = {
  text: {
    label: 'Text to Video',
    icon: <Type className="h-5 w-5" />,
    description: 'Describe a scene and Wan3.0 generates a cinematic video from text alone.',
    gradient: 'from-cyan-500 to-blue-600',
  },
  image: {
    label: 'Image to Video',
    icon: <ImageIcon className="h-5 w-5" />,
    description: 'Upload a first frame image and animate it into a 5-second video.',
    gradient: 'from-violet-500 to-fuchsia-600',
  },
  reference: {
    label: 'Reference to Video',
    icon: <Users className="h-5 w-5" />,
    description: 'Provide a product image and a character reference for a multi-modal ad video.',
    gradient: 'from-amber-400 to-orange-500',
  },
};

const PROMPT_EXAMPLES: Record<Mode, string[]> = {
  text: [
    'A spaceship crafted from plush fabric blasts off from a yarn planet, then is swallowed by a colossal deep-blue plush whale.',
    'A giant black beetle carrying bundled cargo and a hooded rider strides across a slope carpeted in bright red moss in a mist-shrouded alien landscape.',
  ],
  image: [
    'Animate the input image: the beetle\'s six legs step alternately, body bobbing gently with each stride. Slow lateral tracking shot, no cuts.',
    'Bring this portrait to life: subtle facial expressions, wind blowing through hair, gentle camera push-in over 5 seconds.',
  ],
  reference: [
    'A young man wearing the reference sneakers performs a street dance routine, showcasing the shoes in motion. Hip-hop commercial style.',
    'The reference character holds the reference product and smiles, turning to camera in a bright studio setting.',
  ],
};

const GENERATION_STAGES = [
  'Initializing Wan3.0 video model...',
  'Processing prompt & reference inputs...',
  'Generating keyframes...',
  'Interpolating motion sequences...',
  'Rendering video frames...',
  'Synthesizing audio track...',
  'Encoding final video output...',
];

export function AIVideoStudio() {
  const [mode, setMode] = useState<Mode>('text');
  const [prompt, setPrompt] = useState('');
  const [resolution, setResolution] = useState<Resolution>('720P');
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('adaptive');
  const [duration, setDuration] = useState<Duration>('auto');
  const [audio, setAudio] = useState(true);
  const [promptExtend, setPromptExtend] = useState(true);
  const [watermark, setWatermark] = useState(false);
  const [images, setImages] = useState<UploadedImage[]>([]);
  const [generating, setGenerating] = useState(false);
  const [stageIdx, setStageIdx] = useState(-1);
  const [result, setResult] = useState<GenerationResult | null>(null);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const requiredImages: Record<Mode, number> = {
    text: 0,
    image: 1,
    reference: 2,
  };

  const imageLabels: Record<Mode, string[]> = {
    text: [],
    image: ['First Frame Image'],
    reference: ['Product / Subject Image', 'Character / Scene Image'],
  };

  const handleModeChange = (newMode: Mode) => {
    setMode(newMode);
    setImages([]);
    setPrompt('');
    setResult(null);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    const newImages: UploadedImage[] = [];
    for (let i = 0; i < files.length && images.length + newImages.length < requiredImages[mode]; i++) {
      const file = files[i];
      newImages.push({ name: file.name, url: URL.createObjectURL(file) });
    }
    setImages([...images, ...newImages]);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    if (images.length < requiredImages[mode]) return;

    setGenerating(true);
    setResult(null);
    setStageIdx(0);

    for (let i = 0; i < GENERATION_STAGES.length; i++) {
      setStageIdx(i);
      await new Promise((r) => setTimeout(r, 600));
    }

    setResult({
      prompt,
      mode,
      resolution,
      duration,
      audio,
      seed: Math.floor(Math.random() * 2000000000),
    });

    setGenerating(false);
    setStageIdx(-1);
  };

  const handleReset = () => {
    setResult(null);
    setPrompt('');
    setImages([]);
  };

  const canGenerate = prompt.trim().length > 0 && images.length >= requiredImages[mode] && !generating;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500 to-fuchsia-600">
          <Film className="h-6 w-6 text-white" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-white">AI Video Studio</h2>
          <p className="text-sm text-slate-400">Wan3.0-powered video generation · Text, Image, or Reference input</p>
        </div>
      </div>

      {/* Mode Selector */}
      <div className="grid grid-cols-3 gap-3">
        {(Object.keys(MODE_CONFIG) as Mode[]).map((m) => {
          const cfg = MODE_CONFIG[m];
          const active = mode === m;
          return (
            <button
              key={m}
              onClick={() => handleModeChange(m)}
              className={`group relative overflow-hidden rounded-xl border p-4 text-center transition-all ${
                active
                  ? `border-transparent bg-gradient-to-br ${cfg.gradient} tf-glow`
                  : 'border-slate-700 bg-slate-800/50 hover:border-slate-600'
              }`}
            >
              <div className={`mx-auto mb-2 flex h-10 w-10 items-center justify-center rounded-lg ${active ? 'bg-white/20' : 'bg-slate-700'}`}>
                <span className={active ? 'text-white' : 'text-slate-400'}>{cfg.icon}</span>
              </div>
              <p className={`text-sm font-semibold ${active ? 'text-white' : 'text-slate-300'}`}>{cfg.label}</p>
            </button>
          );
        })}
      </div>

      <p className="text-center text-sm text-slate-400">{MODE_CONFIG[mode].description}</p>

      {/* Main Form */}
      <Card className="p-6" glow>
        <div className="space-y-5">
          {/* Image Uploads (conditional) */}
          {requiredImages[mode] > 0 && (
            <div className="space-y-3">
              <label className="block text-sm font-medium text-slate-300">
                {mode === 'reference' ? 'Reference Images' : 'Input Image'}
              </label>
              <div className={`grid gap-3 ${mode === 'reference' ? 'sm:grid-cols-2' : ''}`}>
                {Array.from({ length: requiredImages[mode] }).map((_, idx) => {
                  const img = images[idx];
                  return (
                    <div key={idx}>
                      {img ? (
                        <div className="group relative overflow-hidden rounded-xl border border-slate-700">
                          <img src={img.url} alt={img.name} className="h-40 w-full object-cover" />
                          <div className="absolute inset-0 flex items-center justify-center bg-black/60 opacity-0 transition-opacity group-hover:opacity-100">
                            <button
                              onClick={() => setImages(images.filter((_, i) => i !== idx))}
                              className="rounded-lg bg-rose-500/20 px-3 py-1.5 text-xs font-semibold text-rose-400"
                            >
                              Remove
                            </button>
                          </div>
                          <div className="flex items-center gap-1.5 p-2 text-xs text-slate-400">
                            <Check className="h-3 w-3 text-emerald-400" />
                            {imageLabels[mode][idx]}
                          </div>
                        </div>
                      ) : (
                        <button
                          onClick={() => fileInputRef.current?.click()}
                          className="flex h-40 w-full flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-slate-700 bg-slate-800/30 transition-all hover:border-cyan-500/50 hover:bg-slate-800/50"
                        >
                          <ImageIcon className="h-8 w-8 text-slate-500" />
                          <span className="text-sm text-slate-400">{imageLabels[mode][idx]}</span>
                          <span className="text-xs text-slate-600">Click to upload</span>
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                multiple={mode === 'reference'}
                onChange={handleFileUpload}
                className="hidden"
              />
            </div>
          )}

          {/* Prompt */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="block text-sm font-medium text-slate-300">Generation Prompt</label>
              <button
                onClick={() => {
                  const examples = PROMPT_EXAMPLES[mode];
                  const random = examples[Math.floor(Math.random() * examples.length)];
                  setPrompt(random);
                }}
                className="inline-flex items-center gap-1 text-xs font-medium text-cyan-400 hover:text-cyan-300"
              >
                <Sparkles className="h-3 w-3" /> Try an example
              </button>
            </div>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder={
                mode === 'text'
                  ? 'Describe the scene you want to generate. Include subject, motion, camera language, lighting, and audio design...'
                  : mode === 'image'
                  ? 'Describe how to animate the input image. Specify motion elements, camera movement, and keep the composition unchanged...'
                  : 'Describe the video using @Image1 as the product/subject reference and @Image2 as the character/scene reference...'
              }
              rows={6}
              className="w-full resize-none rounded-xl border border-slate-700 bg-slate-800/80 px-4 py-3 text-sm text-slate-200 placeholder:text-slate-500 transition-colors hover:border-cyan-500/50 focus:border-cyan-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/20"
            />
            <p className="text-xs text-slate-500">
              {prompt.length} characters · Detailed prompts with motion, camera, and audio instructions produce better results
            </p>
          </div>

          {/* Quick Settings */}
          <div className="grid gap-3 sm:grid-cols-3">
            <div className="space-y-2">
              <label className="text-xs font-medium text-slate-400">Resolution</label>
              <div className="grid grid-cols-3 gap-1">
                {(['480P', '720P', '1080P'] as Resolution[]).map((r) => (
                  <button
                    key={r}
                    onClick={() => setResolution(r)}
                    className={`rounded-lg border py-2 text-xs font-semibold transition-all ${
                      resolution === r ? 'border-cyan-500 bg-cyan-500/10 text-cyan-400' : 'border-slate-700 bg-slate-800/50 text-slate-400 hover:border-slate-600'
                    }`}
                  >
                    {r}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-medium text-slate-400">Aspect Ratio</label>
              <div className="grid grid-cols-2 gap-1">
                {(['adaptive', '16:9', '9:16', '1:1'] as AspectRatio[]).map((r) => (
                  <button
                    key={r}
                    onClick={() => setAspectRatio(r)}
                    className={`rounded-lg border py-2 text-xs font-semibold transition-all ${
                      aspectRatio === r ? 'border-cyan-500 bg-cyan-500/10 text-cyan-400' : 'border-slate-700 bg-slate-800/50 text-slate-400 hover:border-slate-600'
                    }`}
                  >
                    {r}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-medium text-slate-400">Duration</label>
              <div className="grid grid-cols-2 gap-1">
                {(['auto', '5'] as Duration[]).map((d) => (
                  <button
                    key={d}
                    onClick={() => setDuration(d)}
                    className={`rounded-lg border py-2 text-xs font-semibold transition-all ${
                      duration === d ? 'border-cyan-500 bg-cyan-500/10 text-cyan-400' : 'border-slate-700 bg-slate-800/50 text-slate-400 hover:border-slate-600'
                    }`}
                  >
                    {d === 'auto' ? 'Auto' : '5 sec'}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Toggle Settings */}
          <div className="flex flex-wrap gap-3">
            <ToggleChip
              label="Audio"
              icon={<Volume2 className="h-4 w-4" />}
              active={audio}
              onClick={() => setAudio(!audio)}
            />
            <ToggleChip
              label="Prompt Expand"
              icon={<Wand2 className="h-4 w-4" />}
              active={promptExtend}
              onClick={() => setPromptExtend(!promptExtend)}
            />
            <ToggleChip
              label="Watermark"
              icon={<Settings2 className="h-4 w-4" />}
              active={watermark}
              onClick={() => setWatermark(!watermark)}
            />
          </div>

          <Button onClick={handleGenerate} disabled={!canGenerate} size="lg" fullWidth>
            {generating ? (
              <><Loader2 className="h-5 w-5 animate-spin" /> Generating Video...</>
            ) : (
              <><Film className="h-5 w-5" /> Generate with Wan3.0</>
            )}
          </Button>
        </div>
      </Card>

      {/* Generation Progress */}
      {generating && (
        <Card className="p-6 tf-fade-in">
          <div className="mb-4 flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-violet-500/10">
              <Cpu className="h-5 w-5 animate-pulse text-violet-400" />
            </div>
            <div>
              <p className="font-semibold text-white">Wan3.0 Processing</p>
              <p className="text-xs text-slate-400">Model: wan3.0-video · {resolution} · {aspectRatio}</p>
            </div>
          </div>
          <div className="space-y-2.5">
            {GENERATION_STAGES.map((s, i) => {
              const done = i < stageIdx;
              const current = i === stageIdx;
              return (
                <div key={s} className={`flex items-center gap-3 text-sm transition-opacity ${current || done ? 'opacity-100' : 'opacity-30'}`}>
                  {done ? (
                    <Check className="h-5 w-5 text-emerald-400" />
                  ) : current ? (
                    <Loader2 className="h-5 w-5 animate-spin text-violet-400" />
                  ) : (
                    <div className="h-5 w-5 rounded-full border-2 border-slate-700" />
                  )}
                  <span className={done ? 'text-slate-500' : current ? 'text-violet-400' : 'text-slate-600'}>{s}</span>
                </div>
              );
            })}
          </div>
        </Card>
      )}

      {/* Result */}
      {result && !generating && (
        <div className="space-y-4 tf-scale-in">
          <Card className="overflow-hidden" glow>
            {/* Video Preview Placeholder */}
            <div className="relative aspect-video bg-gradient-to-br from-slate-800 to-slate-900">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="flex flex-col items-center gap-3">
                  <div className="flex h-16 w-16 items-center justify-center rounded-full bg-violet-500/20">
                    <Film className="h-8 w-8 text-violet-400" />
                  </div>
                  <p className="text-sm font-medium text-slate-300">Video Preview</p>
                  <p className="text-xs text-slate-500">Wan3.0 · {result.resolution} · {result.duration === 'auto' ? 'Auto duration' : '5 seconds'}</p>
                </div>
              </div>
              <div className="absolute bottom-0 left-0 right-0 flex items-center justify-between bg-gradient-to-t from-black/80 to-transparent p-4">
                <div className="flex items-center gap-2">
                  {result.audio && (
                    <Badge variant="accent"><Volume2 className="h-3 w-3" /> Audio</Badge>
                  )}
                  <Badge variant="default">{result.resolution}</Badge>
                  <Badge variant="default">Seed: {result.seed}</Badge>
                </div>
                <button className="rounded-lg bg-white/10 p-2 text-white backdrop-blur transition-colors hover:bg-white/20">
                  <Download className="h-5 w-5" />
                </button>
              </div>
            </div>
          </Card>

          {/* Prompt Recap */}
          <Card className="p-5">
            <div className="mb-2 flex items-center gap-2">
              <Type className="h-4 w-4 text-violet-400" />
              <h4 className="text-sm font-semibold text-white">Generation Prompt</h4>
            </div>
            <p className="text-sm text-slate-300">{result.prompt}</p>
          </Card>

          {/* Metadata */}
          <div className="grid gap-3 sm:grid-cols-4">
            <Card className="flex items-center gap-3 p-4">
              <Monitor className="h-5 w-5 text-cyan-400" />
              <div>
                <p className="text-xs text-slate-500">Resolution</p>
                <p className="text-sm font-semibold text-white">{result.resolution}</p>
              </div>
            </Card>
            <Card className="flex items-center gap-3 p-4">
              <Clock className="h-5 w-5 text-cyan-400" />
              <div>
                <p className="text-xs text-slate-500">Duration</p>
                <p className="text-sm font-semibold text-white">{result.duration === 'auto' ? 'Auto' : '5s'}</p>
              </div>
            </Card>
            <Card className="flex items-center gap-3 p-4">
              <Volume2 className="h-5 w-5 text-cyan-400" />
              <div>
                <p className="text-xs text-slate-500">Audio</p>
                <p className="text-sm font-semibold text-white">{result.audio ? 'Enabled' : 'Off'}</p>
              </div>
            </Card>
            <Card className="flex items-center gap-3 p-4">
              <Cpu className="h-5 w-5 text-cyan-400" />
              <div>
                <p className="text-xs text-slate-500">Model</p>
                <p className="text-sm font-semibold text-white">Wan3.0</p>
              </div>
            </Card>
          </div>

          {/* Actions */}
          <div className="flex gap-3">
            <Button variant="secondary" fullWidth onClick={handleReset}>
              <RefreshCw className="h-4 w-4" /> New Generation
            </Button>
            <Button fullWidth>
              <Download className="h-4 w-4" /> Download Video
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

function ToggleChip({
  label,
  icon,
  active,
  onClick,
}: {
  label: string;
  icon: React.ReactNode;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`inline-flex items-center gap-2 rounded-xl border px-4 py-2.5 text-sm font-medium transition-all ${
        active
          ? 'border-cyan-500/50 bg-cyan-500/10 text-cyan-400'
          : 'border-slate-700 bg-slate-800/50 text-slate-400 hover:border-slate-600'
      }`}
    >
      {icon}
      {label}
      <span className={`ml-1 h-2 w-2 rounded-full ${active ? 'bg-cyan-400' : 'bg-slate-600'}`} />
    </button>
  );
}
