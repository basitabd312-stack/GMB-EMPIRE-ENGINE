import { type ReactNode } from 'react';

interface CardProps {
  children: ReactNode;
  className?: string;
  hover?: boolean;
  glow?: boolean;
}

export function Card({ children, className = '', hover = false, glow = false }: CardProps) {
  return (
    <div
      className={`rounded-2xl border border-slate-700/80 bg-[#151b2e]/80 ${hover ? 'tf-card-hover' : ''} ${glow ? 'tf-glow' : ''} ${className}`}
    >
      {children}
    </div>
  );
}
