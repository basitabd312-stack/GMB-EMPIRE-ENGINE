interface SliderProps {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  unit?: string;
  onChange: (value: number) => void;
}

export function Slider({ label, value, min, max, step = 1, unit, onChange }: SliderProps) {
  const percent = ((value - min) / (max - min)) * 100;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <label className="text-sm font-medium text-slate-300">{label}</label>
        <span className="rounded-lg bg-cyan-500/10 px-3 py-1 text-sm font-bold text-cyan-400">
          {value}{unit ? ` ${unit}` : ''}
        </span>
      </div>
      <div className="relative">
        <div className="h-2 rounded-full bg-slate-700">
          <div
            className="h-2 rounded-full bg-gradient-to-r from-cyan-500 to-blue-500"
            style={{ width: `${percent}%` }}
          />
        </div>
        <input
          type="range"
          min={min}
          max={max}
          step={step}
          value={value}
          onChange={(e) => onChange(Number(e.target.value))}
          className="tf-range absolute inset-0 h-full w-full cursor-pointer appearance-none bg-transparent"
          style={{ height: '22px', top: '-9px' }}
        />
      </div>
      <div className="flex justify-between text-xs text-slate-500">
        <span>{min}{unit ? ` ${unit}` : ''}</span>
        <span>{max}{unit ? ` ${unit}` : ''}</span>
      </div>
    </div>
  );
}
