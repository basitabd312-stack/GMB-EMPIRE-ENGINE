import { useState } from 'react';
import { Video, Image as ImageIcon, User, Loader2, Check, AlertCircle, DollarSign, MapPin } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Select } from '@/components/ui/Select';
import { Slider } from '@/components/ui/Slider';
import { Badge } from '@/components/ui/Badge';
import {
  type Quality,
  type BusinessCategory,
  type ScriptType,
  type GeoTier,
  calculatePricing,
  getGeoTierForCountry,
  type PricingResult,
} from '@/lib/pricing';

export function UGCAdsGenerator() {
  const [businessName, setBusinessName] = useState('');
  const [duration, setDuration] = useState(10);
  const [quality, setQuality] = useState<Quality>('4K');
  const [businessCategory, setBusinessCategory] = useState<BusinessCategory>('Clothing/Ecom');
  const [scriptType, setScriptType] = useState<ScriptType>('High Sales');
  const [country, setCountry] = useState('United States');
  const [imageUploaded, setImageUploaded] = useState(false);
  const [pricing, setPricing] = useState<PricingResult | null>(null);
  const [generating, setGenerating] = useState(false);
  const [generated, setGenerated] = useState(false);
  const [confirmStep, setConfirmStep] = useState(false);

  const geoTier = getGeoTierForCountry(country);

  const handleCalculate = () => {
    const result = calculatePricing({
      seconds: duration,
      quality,
      businessCategory,
      scriptType,
      geoTier,
      country,
    });
    setPricing(result);
    setConfirmStep(true);
  };

  const handleGenerate = async () => {
    setGenerating(true);
    await new Promise((r) => setTimeout(r, 3500));
    setGenerating(false);
    setGenerated(true);
  };

  const handleReset = () => {
    setGenerated(false);
    setConfirmStep(false);
    setPricing(null);
    setImageUploaded(false);
    setBusinessName('');
    setDuration(10);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-amber-400 to-orange-500">
          <Video className="h-6 w-6 text-slate-900" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-white">UGC Ads Generator</h2>
          <p className="text-sm text-slate-400">Ultra-realistic testimonial ads · Pay-per-second</p>
        </div>
      </div>

      <Card className="p-6" glow>
        <div className="space-y-5">
          {/* Product Image Upload */}
          <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-300">Product Image</label>
            <button
              onClick={() => setImageUploaded(!imageUploaded)}
              className={`flex w-full flex-col items-center gap-2 rounded-xl border-2 border-dashed p-8 transition-all ${
                imageUploaded
                  ? 'border-emerald-500/50 bg-emerald-500/5'
                  : 'border-slate-700 bg-slate-800/30 hover:border-cyan-500/50 hover:bg-slate-800/50'
              }`}
            >
              {imageUploaded ? (
                <>
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-emerald-500/10">
                    <Check className="h-6 w-6 text-emerald-400" />
                  </div>
                  <p className="text-sm font-medium text-emerald-400">Product image uploaded</p>
                  <p className="text-xs text-slate-500">Click to replace</p>
                </>
              ) : (
                <>
                  <ImageIcon className="h-8 w-8 text-slate-500" />
                  <p className="text-sm text-slate-400">Click to upload product image</p>
                  <p className="text-xs text-slate-600">PNG, JPG up to 10MB</p>
                </>
              )}
            </button>
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-300">Business Name</label>
            <input
              type="text"
              value={businessName}
              onChange={(e) => setBusinessName(e.target.value)}
              placeholder="e.g. Glow Beauty Store"
              className="w-full rounded-xl border border-slate-700 bg-slate-800/80 px-4 py-3 text-sm text-slate-200 placeholder:text-slate-500 transition-colors hover:border-cyan-500/50 focus:border-cyan-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/20"
            />
          </div>

          <Slider
            label="Duration"
            value={duration}
            min={5}
            max={30}
            unit="sec"
            onChange={setDuration}
          />

          <Select
            label="Quality"
            value={quality}
            onChange={(v) => setQuality(v as Quality)}
            options={[
              { value: '1080p', label: '1080p · $28/sec' },
              { value: '3K', label: '3K · $45/sec' },
              { value: '4K', label: '4K · $50/sec' },
            ]}
          />

          <div className="grid gap-4 sm:grid-cols-2">
            <Select
              label="Business Category"
              value={businessCategory}
              onChange={(v) => setBusinessCategory(v as BusinessCategory)}
              options={[
                { value: 'Small/General/Salon', label: 'Small / General / Salon · 1.0x' },
                { value: 'Restaurant', label: 'Restaurant · 1.2x' },
                { value: 'Clothing/Ecom', label: 'Clothing / Ecom · 1.5x' },
                { value: 'Real Estate/Cars', label: 'Real Estate / Cars · 2.0x' },
              ]}
            />
            <Select
              label="Script Type"
              value={scriptType}
              onChange={(v) => setScriptType(v as ScriptType)}
              options={[
                { value: 'Review', label: 'Review · 1.0x' },
                { value: 'Demo', label: 'Demo · 1.3x' },
                { value: 'High Sales', label: 'High Sales · 1.5x' },
              ]}
            />
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-300">Location (Auto-Detected)</label>
            <div className="flex items-center gap-3">
              <div className="relative flex-1">
                <MapPin className="pointer-events-none absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-cyan-400" />
                <select
                  value={country}
                  onChange={(e) => setCountry(e.target.value)}
                  className="w-full appearance-none rounded-xl border border-slate-700 bg-slate-800/80 py-3 pl-10 pr-4 text-sm text-slate-200 transition-colors hover:border-cyan-500/50 focus:border-cyan-500 focus:outline-none"
                >
                  <optgroup label="Tier 1 (1.0x)">
                    <option>United States</option>
                    <option>United Kingdom</option>
                    <option>Canada</option>
                    <option>Australia</option>
                    <option>Germany</option>
                    <option>France</option>
                  </optgroup>
                  <optgroup label="Middle East (0.7x)">
                    <option>United Arab Emirates</option>
                    <option>Saudi Arabia</option>
                    <option>Qatar</option>
                  </optgroup>
                  <optgroup label="Pakistan/India/BD (0.35x)">
                    <option>Pakistan</option>
                    <option>India</option>
                    <option>Bangladesh</option>
                  </optgroup>
                </select>
              </div>
              <Badge variant="accent">{geoTier}</Badge>
            </div>
          </div>

          {!confirmStep ? (
            <Button
              onClick={handleCalculate}
              disabled={!businessName.trim() || !imageUploaded}
              size="lg"
              fullWidth
              variant="gold"
            >
              <DollarSign className="h-5 w-5" />
              Calculate Price
            </Button>
          ) : (
            <div className="space-y-4 tf-scale-in">
              <Card className="border-cyan-500/30 p-5 tf-glow">
                <div className="mb-3 flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-cyan-400" />
                  <h4 className="font-semibold text-white">Price Confirmation</h4>
                </div>
                <div className="mb-4 space-y-1.5 text-sm text-slate-300">
                  <div className="flex justify-between"><span>Duration</span><span className="font-semibold text-white">{pricing!.seconds} sec</span></div>
                  <div className="flex justify-between"><span>Quality</span><span className="font-semibold text-white">{pricing!.quality} · ${pricing!.qualityRate}/sec</span></div>
                  <div className="flex justify-between"><span>Business</span><span className="font-semibold text-white">{pricing!.businessCategory} · {pricing!.businessMultiplier}x</span></div>
                  <div className="flex justify-between"><span>Script</span><span className="font-semibold text-white">{pricing!.scriptType} · {pricing!.scriptMultiplier}x</span></div>
                  <div className="flex justify-between"><span>Location</span><span className="font-semibold text-white">{pricing!.country} · {pricing!.geoMultiplier}x</span></div>
                </div>
                <div className="rounded-xl bg-slate-800/80 p-3 text-center">
                  <p className="text-xs text-slate-400">{pricing!.formula}</p>
                </div>
                <div className="mt-4 flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-amber-500/10 to-orange-500/10 py-4">
                  <span className="text-3xl font-bold text-amber-400">{pricing!.finalCredits}</span>
                  <span className="text-sm text-slate-400">Credits · ${pricing!.finalCredits} USD</span>
                </div>
                <p className="mt-3 text-center text-sm text-slate-400">
                  {pricing!.finalCredits} Credits will be deducted. Do you want to generate?
                </p>
                <div className="mt-4 flex gap-3">
                  <Button variant="secondary" fullWidth onClick={() => setConfirmStep(false)}>
                    No, Go Back
                  </Button>
                  <Button variant="gold" fullWidth onClick={handleGenerate} disabled={generating}>
                    {generating ? (
                      <><Loader2 className="h-5 w-5 animate-spin" /> Generating...</>
                    ) : (
                      <><Check className="h-5 w-5" /> Yes, Generate</>
                    )}
                  </Button>
                </div>
              </Card>
            </div>
          )}
        </div>
      </Card>

      {generating && (
        <Card className="p-8 tf-fade-in">
          <div className="flex flex-col items-center gap-4 text-center">
            <Loader2 className="h-12 w-12 animate-spin text-amber-400" />
            <div>
              <p className="font-semibold text-white">Generating your UGC ad...</p>
              <p className="mt-1 text-sm text-slate-400">
                Creating ultra-realistic 4K human · Real skin texture · {businessName} testimonial
              </p>
            </div>
            <div className="flex gap-2">
              {['AI Face', 'B-Roll', 'Captions', 'Music'].map((s) => (
                <Badge key={s} variant="gold">{s}</Badge>
              ))}
            </div>
          </div>
        </Card>
      )}

      {generated && !generating && (
        <Card className="p-6 tf-scale-in" glow>
          <div className="flex flex-col items-center gap-4 text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-emerald-500/10 tf-glow">
              <Check className="h-8 w-8 text-emerald-400" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-white">UGC Ad Ready!</h3>
              <p className="mt-1 text-sm text-slate-400">
                {duration}s · {quality} · {businessName} · {scriptType}
              </p>
            </div>
            <div className="w-full max-w-md rounded-xl border border-slate-700 bg-slate-800/50 p-4">
              <div className="mb-2 flex items-center gap-2">
                <User className="h-4 w-4 text-amber-400" />
                <span className="text-xs font-semibold uppercase tracking-wide text-amber-400">Script Preview</span>
              </div>
              <p className="text-sm italic text-slate-300">
                "Guys, I just got this from {businessName} and I'm honestly obsessed! The quality is insane and it came so fast. If you're thinking about getting one, just do it — you won't regret it!"
              </p>
            </div>
            <div className="flex flex-wrap justify-center gap-2">
              <Badge variant="success"><Check className="h-3 w-3" /> No logo</Badge>
              <Badge variant="success"><Check className="h-3 w-3" /> No subtitles</Badge>
              <Badge variant="success"><Check className="h-3 w-3" /> UGC style</Badge>
              <Badge variant="success"><Check className="h-3 w-3" /> 25-35 age actor</Badge>
            </div>
            <Button variant="secondary" onClick={handleReset}>
              <Video className="h-4 w-4" /> Create Another Ad
            </Button>
          </div>
        </Card>
      )}

      {!imageUploaded && !confirmStep && (
        <div className="flex items-start gap-2 rounded-xl border border-amber-500/20 bg-amber-500/5 p-4">
          <AlertCircle className="mt-0.5 h-5 w-5 flex-shrink-0 text-amber-400" />
          <p className="text-sm text-slate-300">
            Upload a product image and enter your business name to calculate pricing. UGC ads are pay-per-second — no packages, no subscriptions.
          </p>
        </div>
      )}
    </div>
  );
}
