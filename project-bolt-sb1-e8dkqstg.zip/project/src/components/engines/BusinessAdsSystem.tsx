import { useState } from 'react';
import { Building2, Store, UtensilsCrossed, Shirt, Home, Check, ChevronRight, ChevronLeft, Star, Zap } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { type BusinessCategory, type ScriptType, type Quality, QUALITY_RATES, BUSINESS_MULTIPLIERS, SCRIPT_MULTIPLIERS } from '@/lib/pricing';

interface Step {
  number: number;
  title: string;
}

const steps: Step[] = [
  { number: 1, title: 'Business Category' },
  { number: 2, title: 'Script Type' },
  { number: 3, title: 'Duration' },
  { number: 4, title: 'Quality' },
];

const categoryIcons: Record<BusinessCategory, React.ReactNode> = {
  'Small/General/Salon': <Store className="h-6 w-6" />,
  'Restaurant': <UtensilsCrossed className="h-6 w-6" />,
  'Clothing/Ecom': <Shirt className="h-6 w-6" />,
  'Real Estate/Cars': <Home className="h-6 w-6" />,
};

export function BusinessAdsSystem() {
  const [step, setStep] = useState(1);
  const [category, setCategory] = useState<BusinessCategory | null>(null);
  const [scriptType, setScriptType] = useState<ScriptType | null>(null);
  const [duration, setDuration] = useState(15);
  const [quality, setQuality] = useState<Quality>('4K');
  const [completed, setCompleted] = useState(false);

  const categories: BusinessCategory[] = ['Small/General/Salon', 'Restaurant', 'Clothing/Ecom', 'Real Estate/Cars'];
  const scriptTypes: ScriptType[] = ['Review', 'Demo', 'High Sales'];
  const qualities: Quality[] = ['1080p', '3K', '4K'];

  const handleNext = () => {
    if (step < 4) setStep(step + 1);
    else setCompleted(true);
  };

  const handleBack = () => {
    if (step > 1) setStep(step - 1);
  };

  const handleReset = () => {
    setStep(1);
    setCategory(null);
    setScriptType(null);
    setDuration(15);
    setQuality('4K');
    setCompleted(false);
  };

  if (completed && category && scriptType) {
    const basePrice = duration * QUALITY_RATES[quality];
    const withBusiness = basePrice * BUSINESS_MULTIPLIERS[category];
    const withScript = withBusiness * SCRIPT_MULTIPLIERS[scriptType];

    return (
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600">
            <Building2 className="h-6 w-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-white">Business Ads System</h2>
            <p className="text-sm text-slate-400">Configuration complete</p>
          </div>
        </div>

        <Card className="p-6 tf-glow" glow>
          <div className="mb-6 flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-emerald-500/10">
              <Check className="h-6 w-6 text-emerald-400" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Campaign Ready</h3>
              <p className="text-sm text-slate-400">Review your configuration</p>
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="rounded-xl border border-slate-700 bg-slate-800/50 p-4">
              <p className="text-xs text-slate-500">Business Category</p>
              <p className="mt-1 font-semibold text-white">{category}</p>
              <Badge variant="accent">{BUSINESS_MULTIPLIERS[category]}x multiplier</Badge>
            </div>
            <div className="rounded-xl border border-slate-700 bg-slate-800/50 p-4">
              <p className="text-xs text-slate-500">Script Type</p>
              <p className="mt-1 font-semibold text-white">{scriptType}</p>
              <Badge variant="accent">{SCRIPT_MULTIPLIERS[scriptType]}x multiplier</Badge>
            </div>
            <div className="rounded-xl border border-slate-700 bg-slate-800/50 p-4">
              <p className="text-xs text-slate-500">Duration</p>
              <p className="mt-1 font-semibold text-white">{duration} seconds</p>
            </div>
            <div className="rounded-xl border border-slate-700 bg-slate-800/50 p-4">
              <p className="text-xs text-slate-500">Quality</p>
              <p className="mt-1 font-semibold text-white">{quality}</p>
              <Badge variant="gold">${QUALITY_RATES[quality]}/sec</Badge>
            </div>
          </div>

          <div className="mt-6 rounded-xl bg-gradient-to-r from-cyan-500/10 to-blue-500/10 p-5">
            <p className="mb-2 text-center text-xs text-slate-400">Base price (before geo multiplier)</p>
            <div className="flex items-center justify-center gap-2">
              <span className="text-3xl font-bold text-cyan-400">${Math.round(withScript)}</span>
              <span className="text-sm text-slate-400">USD estimated</span>
            </div>
            <p className="mt-2 text-center text-xs text-slate-500">
              {duration} × {QUALITY_RATES[quality]} × {BUSINESS_MULTIPLIERS[category]} × {SCRIPT_MULTIPLIERS[scriptType]} = {Math.round(withScript)}
            </p>
          </div>

          <div className="mt-4 flex gap-3">
            <Button variant="secondary" fullWidth onClick={handleReset}>
              <ChevronLeft className="h-4 w-4" /> Start Over
            </Button>
            <Button fullWidth onClick={() => {}}>
              Proceed to UGC Generator <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600">
          <Building2 className="h-6 w-6 text-white" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-white">Business Ads System</h2>
          <p className="text-sm text-slate-400">4-step onboarding wizard</p>
        </div>
      </div>

      {/* Progress */}
      <div className="flex items-center gap-2">
        {steps.map((s, i) => (
          <div key={s.number} className="flex flex-1 items-center gap-2">
            <div className={`flex h-8 w-8 items-center justify-center rounded-full text-xs font-bold transition-all ${
              step > s.number ? 'bg-emerald-500/20 text-emerald-400' : step === s.number ? 'bg-cyan-500 text-white' : 'bg-slate-800 text-slate-500'
            }`}>
              {step > s.number ? <Check className="h-4 w-4" /> : s.number}
            </div>
            <span className={`hidden text-xs font-medium sm:inline ${step >= s.number ? 'text-slate-300' : 'text-slate-600'}`}>
              {s.title}
            </span>
            {i < steps.length - 1 && <div className={`h-0.5 flex-1 ${step > s.number ? 'bg-emerald-500/50' : 'bg-slate-700'}`} />}
          </div>
        ))}
      </div>

      <Card className="p-6" glow>
        {step === 1 && (
          <div className="space-y-4 tf-fade-in">
            <h3 className="text-lg font-bold text-white">Select Business Category</h3>
            <div className="grid gap-3 sm:grid-cols-2">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setCategory(cat)}
                  className={`flex items-center gap-3 rounded-xl border p-4 text-left transition-all ${
                    category === cat ? 'border-cyan-500 bg-cyan-500/10 tf-glow' : 'border-slate-700 bg-slate-800/50 hover:border-cyan-500/50'
                  }`}
                >
                  <div className={`flex h-12 w-12 items-center justify-center rounded-xl ${category === cat ? 'bg-cyan-500/20 text-cyan-400' : 'bg-slate-700 text-slate-400'}`}>
                    {categoryIcons[cat]}
                  </div>
                  <div className="flex-1">
                    <p className="font-semibold text-white">{cat}</p>
                    <Badge variant="accent">{BUSINESS_MULTIPLIERS[cat]}x</Badge>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-4 tf-fade-in">
            <h3 className="text-lg font-bold text-white">Select Script Type</h3>
            <div className="grid gap-3 sm:grid-cols-3">
              {scriptTypes.map((st) => (
                <button
                  key={st}
                  onClick={() => setScriptType(st)}
                  className={`rounded-xl border p-5 text-center transition-all ${
                    scriptType === st ? 'border-cyan-500 bg-cyan-500/10 tf-glow' : 'border-slate-700 bg-slate-800/50 hover:border-cyan-500/50'
                  }`}
                >
                  {st === 'Review' && <Star className="mx-auto mb-2 h-6 w-6 text-amber-400" />}
                  {st === 'Demo' && <Zap className="mx-auto mb-2 h-6 w-6 text-cyan-400" />}
                  {st === 'High Sales' && <ChevronRight className="mx-auto mb-2 h-6 w-6 text-rose-400" />}
                  <p className="font-semibold text-white">{st}</p>
                  <Badge variant="accent">{SCRIPT_MULTIPLIERS[st]}x</Badge>
                </button>
              ))}
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-6 tf-fade-in">
            <h3 className="text-lg font-bold text-white">Select Duration</h3>
            <div className="rounded-xl border border-slate-700 bg-slate-800/50 p-6">
              <div className="mb-4 flex items-center justify-between">
                <span className="text-sm text-slate-400">Duration</span>
                <span className="rounded-lg bg-cyan-500/10 px-4 py-1 text-lg font-bold text-cyan-400">{duration} sec</span>
              </div>
              <input
                type="range"
                min={5}
                max={30}
                value={duration}
                onChange={(e) => setDuration(Number(e.target.value))}
                className="tf-range w-full"
              />
              <div className="mt-2 flex justify-between text-xs text-slate-500">
                <span>5 sec (min)</span>
                <span>30 sec (max)</span>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              {[5, 10, 15, 20, 25, 30].map((d) => (
                <button
                  key={d}
                  onClick={() => setDuration(d)}
                  className={`rounded-lg border px-4 py-2 text-sm font-semibold transition-all ${
                    duration === d ? 'border-cyan-500 bg-cyan-500/10 text-cyan-400' : 'border-slate-700 bg-slate-800/50 text-slate-400 hover:border-cyan-500/50'
                  }`}
                >
                  {d}s
                </button>
              ))}
            </div>
          </div>
        )}

        {step === 4 && (
          <div className="space-y-4 tf-fade-in">
            <h3 className="text-lg font-bold text-white">Select Quality</h3>
            <div className="grid gap-3 sm:grid-cols-3">
              {qualities.map((q) => (
                <button
                  key={q}
                  onClick={() => setQuality(q)}
                  className={`rounded-xl border p-6 text-center transition-all ${
                    quality === q ? 'border-amber-500 bg-amber-500/10 tf-glow-gold' : 'border-slate-700 bg-slate-800/50 hover:border-amber-500/50'
                  }`}
                >
                  <p className="text-xl font-bold text-white">{q}</p>
                  <p className="mt-1 text-sm text-slate-400">${QUALITY_RATES[q]}/sec</p>
                  {q === '4K' && <Badge variant="gold">Best Quality</Badge>}
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="mt-6 flex gap-3">
          {step > 1 && (
            <Button variant="secondary" onClick={handleBack}>
              <ChevronLeft className="h-4 w-4" /> Back
            </Button>
          )}
          <Button fullWidth onClick={handleNext} disabled={(step === 1 && !category) || (step === 2 && !scriptType)}>
            {step < 4 ? 'Continue' : 'Complete Setup'} <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </Card>
    </div>
  );
}
