/*
# Create projects table for TubeFactoryAI

1. New Tables
- `projects`
- `id` (uuid, primary key)
- `engine` (text, which engine: youtube_factory, ugc_ads, video_edit, business_ads)
- `title` (text, project name)
- `status` (text, draft/pending/completed)
- `config` (jsonb, all engine-specific configuration and results)
- `price_credits` (numeric, calculated price in credits)
- `created_at` (timestamp)
- `updated_at` (timestamp)

2. Security
- Enable RLS on `projects`.
- Single-tenant no-auth app: allow anon + authenticated full CRUD (data is intentionally shared).
*/

CREATE TABLE IF NOT EXISTS projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  engine text NOT NULL,
  title text NOT NULL DEFAULT 'Untitled Project',
  status text NOT NULL DEFAULT 'draft',
  config jsonb NOT NULL DEFAULT '{}'::jsonb,
  price_credits numeric DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE projects ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_projects" ON projects;
CREATE POLICY "anon_select_projects" ON projects FOR SELECT
TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_projects" ON projects;
CREATE POLICY "anon_insert_projects" ON projects FOR INSERT
TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_projects" ON projects;
CREATE POLICY "anon_update_projects" ON projects FOR UPDATE
TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_projects" ON projects;
CREATE POLICY "anon_delete_projects" ON projects FOR DELETE
TO anon, authenticated USING (true);
