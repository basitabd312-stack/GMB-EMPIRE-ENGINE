import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const RUNPOD_API_KEY = Deno.env.get("RUNPOD_API_KEY") || "";
const RUNPOD_BASE = "https://api.runpod.ai/v2";

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { action, endpoint, payload, jobId } = await req.json();

    if (!endpoint) {
      return new Response(
        JSON.stringify({ error: "Missing RunPod endpoint ID" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const baseUrl = `${RUNPOD_BASE}/${endpoint}`;

    if (action === "run") {
      const runRes = await fetch(`${baseUrl}/run`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${RUNPOD_API_KEY}`,
        },
        body: JSON.stringify(payload),
      });

      const runData = await runRes.json();

      if (!runRes.ok) {
        return new Response(
          JSON.stringify({ error: runData.error || "Failed to start RunPod job" }),
          { status: runRes.status, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }

      return new Response(
        JSON.stringify({ id: runData.id, status: runData.status }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    if (action === "status") {
      if (!jobId) {
        return new Response(
          JSON.stringify({ error: "Missing job ID" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }

      const statusRes = await fetch(`${baseUrl}/status/${jobId}`, {
        headers: { "Authorization": `Bearer ${RUNPOD_API_KEY}` },
      });

      const statusData = await statusRes.json();

      if (!statusRes.ok) {
        return new Response(
          JSON.stringify({ error: statusData.error || "Failed to get job status" }),
          { status: statusRes.status, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }

      return new Response(
        JSON.stringify(statusData),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    return new Response(
      JSON.stringify({ error: "Invalid action. Use 'run' or 'status'." }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
